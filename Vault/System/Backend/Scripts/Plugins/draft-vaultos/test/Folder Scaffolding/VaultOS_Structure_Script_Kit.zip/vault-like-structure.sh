#!/bin/bash

# ┌────────────────────────────────────────────────────────────┐
# │ Vault-Like Structure Generator v1.0 - GOLD STANDARD EDITION │
# └────────────────────────────────────────────────────────────┘
# Author: PtiCalin ✨
# Description: Creates a clean VAULT folder structure with folder notes,
# a standard template, and optional Obsidian setup.
# Usage: ./vault-like-structure.sh <VaultFolderName> [--obsidian] [--dry-run]

VAULT_NAME="$1"
WITH_OBSIDIAN=false
DRY_RUN=false

# ───────────────────────────────────────────────
# 🧠 Parse optional flags
# ───────────────────────────────────────────────
for arg in "$@"; do
  if [[ "$arg" == "--obsidian" ]]; then
    WITH_OBSIDIAN=true
  elif [[ "$arg" == "--dry-run" ]]; then
    DRY_RUN=true
  fi
done

if [ -z "$VAULT_NAME" ]; then
  echo "❗ Usage: ./vault-like-structure.sh <VaultName> [--obsidian] [--dry-run]"
  exit 1
fi

echo "🔨 Generating structure in: $VAULT_NAME"
$DRY_RUN && echo "⚠️ Dry run mode: no actual files will be written."

# ───────────────────────────────────────────────
# 📁 Define directory structure
# ───────────────────────────────────────────────
STRUCTURE=(
  "Files and media/Audio"
  "Files and media/Documents"
  "Files and media/Images"
  "Files and media/Other Media"
  "Files and media/Video"
  "Files and media/Web Clippings"
  "Notes/Areas"
  "Notes/Calendar"
  "Notes/Daily Notes"
  "Notes/Journaling"
  "Notes/Meeting Notes"
  "Notes/People"
  "Notes/Projects"
  "System/Backend/Configuration"
  "System/Backend/Data Models"
  "System/Backend/Logs"
  "System/Backend/Metadata"
  "System/Backend/Scripts"
  "System/Backend/Utilities"
  "System/Frontend/Dashboard"
  "System/Frontend/Snippets"
  "System/Frontend/Templates"
  "System/Frontend/Themes"
  "System/Frontend/UX"
  "System/Middleware"
  "System/Documentation and Meta/readme"
)

# ───────────────────────────────────────────────
# 🛠 Create folders and folder notes
# ───────────────────────────────────────────────
for SUBPATH in "${STRUCTURE[@]}"; do
  FULL_PATH="$VAULT_NAME/VAULT/$SUBPATH"
  FOLDER_NAME=$(basename "$SUBPATH")
  NOTE_PATH="$FULL_PATH/$FOLDER_NAME.md"

  if $DRY_RUN; then
    echo "[mkdir] $FULL_PATH"
    echo "[note ] $NOTE_PATH"
  else
    mkdir -p "$FULL_PATH"
    echo "---
id=${FOLDER_NAME,,}.md
title: "$FOLDER_NAME"
aliases: []
author: PtiCalin
element: core
type: section
category: 
section: $FOLDER_NAME
topic: 
folder: $FOLDER_NAME
tags: []
version: 1.0
status: draft
visibility: public
created: $(date +%Y-%m-%d)
updated: $(date +%Y-%m-%d)
summary: "Folder note for $FOLDER_NAME section."
parent: ""
children: []
friends: []
related: []
---

> [!nav] 🚀 Vault Navigation  
> [[🖼 Media Gallery]] • [[🗓 Daily Notes]] • [[📚 Encyclopedia]] • [[🧠 Learnings]] • [[⛮ System]]

## ✍️ Content Title

<!-- Add content in this section -->

---

> [!info] 🕸 Relationships  
> This note is part of a larger structure. Below are its connections:

\`\`\`dataview
table
  parent as "Parent",
  children as "Subpages",
  friends as "Friends",
  related as "Related"
from ""
where file.link = this.file.link
\`\`\`
---" > "$NOTE_PATH"
  fi
done

# ───────────────────────────────────────────────
# 📄 Add Standard Page Template
# ───────────────────────────────────────────────
TEMPLATE_PATH="$VAULT_NAME/VAULT/Templates"
if $DRY_RUN; then
  echo "[mkdir] $TEMPLATE_PATH"
  echo "[file ] Standard Page Template v1.3.md"
else
  mkdir -p "$TEMPLATE_PATH"
  echo "---
id=file_name.fmt 
title: "<% title %>"
aliases: []
author: PtiCalin
element: # 1st layer 
type: # 2nd layer 
category: # 3rd layer 
section: # 4th layer 
topic: # 5th layer 
folder: 
tags: []
version: 1.3
status: <% status %>
visibility: <% visibility %>
created: <% today %>
updated: <% today %>
summary: ""
parent: ""
children: []
friends: []
related: []
---

> [!nav] Vault Navigation  
> [[🖼 Media Gallery]] • [[🗓 Daily Notes]] • [[📚 Encyclopedia]] • [[🧠 Learnings]] • [[⛮ System]]

## ✍️ Content Title

<!-- Add content in this section -->

---

> [!info] 🕸 Relationships  
> This note is part of a larger structure. Below are its connections:

\`\`\`dataview
table
  parent as "Parent",
  children as "Subpages",
  friends as "Friends",
  related as "Related"
from ""
where file.link = this.file.link
\`\`\`
---" > "$TEMPLATE_PATH/Standard Page Template v1.3.md"
fi

# ───────────────────────────────────────────────
# 🗂 Add README and optional .obsidian
# ───────────────────────────────────────────────
if ! $DRY_RUN; then
  echo "# $VAULT_NAME" > "$VAULT_NAME/README.md"
  echo "_Generated on $(date)_ 🚀" >> "$VAULT_NAME/README.md"
fi

if $WITH_OBSIDIAN; then
  OBS_PATH="$VAULT_NAME/.obsidian"
  if $DRY_RUN; then
    echo "[mkdir] $OBS_PATH"
    echo "[file ] workspace.json"
  else
    mkdir -p "$OBS_PATH"
    echo "{
  "lastOpened": "$(date +%Y-%m-%d)",
  "workspace": {
    "main": {
      "type": "empty"
    }
  }
}" > "$OBS_PATH/workspace.json"
  fi
fi

# ✅ Completion message
echo "✅ Vault structure simulated${DRY_RUN:+ (dry run)} successfully."
