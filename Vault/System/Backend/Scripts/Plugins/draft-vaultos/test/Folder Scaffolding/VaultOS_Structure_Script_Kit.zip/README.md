# 🧱 Vault-Like Structure Generator (CLI Tool)

This is the official CLI companion to **VaultOS**, designed to scaffold an entire modular vault structure from any folder on your system.

## 🛠 Usage

```bash
./vault-like-structure.sh <TargetDirectory> [flags]
```

### Flags

| Flag              | Description |
|-------------------|-------------|
| `--dry-run`       | Echo only — simulate file/folder creation |
| `--obsidian`      | Copy your `.obsidian` config into vault system folders |
| `--preset <type>` | Use a predefined layout: `standard`, `learning`, `dev`, `world` |
| `--advanced`      | (Coming soon) Prompt-based folder selection |

## 🎯 Example

```bash
./vault-like-structure.sh MyVault --preset standard --obsidian
```

## 🧭 File Targets

- **Plugins** → `VAULT/System/Backend/Scripts/Native Plugins/Obsidian/`
- **Snippets** → `VAULT/System/Frontend/Obsidian/Snippets/`
- **Other .obsidian config** → `VAULT/System/Middleware/Obsidian/Configuration/`

---

Built with love by PtiCalin 💛
